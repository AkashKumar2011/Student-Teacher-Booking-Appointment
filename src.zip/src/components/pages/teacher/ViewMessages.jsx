// src/components/teacher/ViewMessages.jsx
import React, { useState } from 'react';
import { FiMail, FiSend, FiUser, FiSearch } from 'react-icons/fi';

const ViewMessages = () => {
  const [activeMessage, setActiveMessage] = useState(1);
  const [newMessage, setNewMessage] = useState('');
  
  const conversations = [
    {
      id: 1,
      student: 'John Doe',
      course: 'CS101',
      lastMessage: 'Thank you for the clarification!',
      time: '2 hours ago',
      unread: false
    },
    {
      id: 2,
      student: 'Sarah Johnson',
      course: 'CS201',
      lastMessage: 'I have a question about the assignment...',
      time: 'Yesterday',
      unread: true
    },
    {
      id: 3,
      student: 'Michael Chen',
      course: 'CS301',
      lastMessage: 'When can we meet to discuss the project?',
      time: 'Oct 12',
      unread: false
    }
  ];
  
  const messages = [
    { id: 1, sender: 'student', text: 'Hello Professor, I need help with the assignment', time: '10:30 AM' },
    { id: 2, sender: 'teacher', text: 'Sure, what specific part are you having trouble with?', time: '10:32 AM' },
    { id: 3, sender: 'student', text: 'I\'m confused about the recursion problem', time: '10:35 AM' },
    { id: 4, sender: 'teacher', text: 'I can explain it during office hours tomorrow', time: '10:40 AM' },
    { id: 5, sender: 'student', text: 'Thank you for the clarification!', time: '10:42 AM' },
  ];
  
  const activeConversation = conversations.find(conv => conv.id === activeMessage);
  
  return (
    <div className="p-6 bg-white rounded-xl shadow-lg">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Messages</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Conversation List */}
        <div className="lg:col-span-1 bg-gradient-to-b from-indigo-50 to-purple-50 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search messages..."
                className="w-full pl-10 pr-4 py-2 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="divide-y divide-gray-100 max-h-[calc(100vh-220px)] overflow-y-auto">
            {conversations.map((conversation) => (
              <div 
                key={conversation.id}
                onClick={() => setActiveMessage(conversation.id)}
                className={`p-4 cursor-pointer transition-colors ${
                  activeMessage === conversation.id 
                    ? 'bg-indigo-100 border-l-4 border-indigo-500' 
                    : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center">
                  <div className="relative">
                    <div className="bg-gray-200 border-2 border-dashed rounded-xl w-12 h-12" />
                    {conversation.unread && (
                      <div className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-white"></div>
                    )}
                  </div>
                  <div className="ml-3 flex-1 min-w-0">
                    <div className="flex justify-between">
                      <h3 className="font-semibold text-gray-800 truncate">{conversation.student}</h3>
                      <span className="text-xs text-gray-500">{conversation.time}</span>
                    </div>
                    <p className="text-sm text-gray-600 truncate">{conversation.lastMessage}</p>
                    <span className="text-xs text-indigo-600">{conversation.course}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Message View */}
        <div className="lg:col-span-2 flex flex-col rounded-xl border border-gray-200 overflow-hidden">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 border-b border-gray-200">
            <div className="flex items-center">
              <div className="bg-gray-200 border-2 border-dashed rounded-xl w-10 h-10" />
              <div className="ml-3">
                <h3 className="font-semibold text-gray-800">{activeConversation?.student}</h3>
                <p className="text-sm text-gray-600">{activeConversation?.course}</p>
              </div>
            </div>
          </div>
          
          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
            <div className="space-y-4">
              {messages.map((message) => (
                <div 
                  key={message.id}
                  className={`flex ${
                    message.sender === 'teacher' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div 
                    className={`max-w-xs lg:max-w-md rounded-2xl px-4 py-3 ${
                      message.sender === 'teacher' 
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-700 text-white rounded-br-none' 
                        : 'bg-white border border-gray-200 rounded-bl-none'
                    }`}
                  >
                    <p>{message.text}</p>
                    <p 
                      className={`text-xs mt-1 ${
                        message.sender === 'teacher' ? 'text-indigo-200' : 'text-gray-500'
                      }`}
                    >
                      {message.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Message Input */}
          <div className="p-4 border-t border-gray-200 bg-white">
            <div className="flex items-center">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="w-full pl-4 pr-12 py-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button className="absolute right-3 top-1/2 transform -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700">
                  <FiSend size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewMessages;