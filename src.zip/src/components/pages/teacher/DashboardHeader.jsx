// src/components/teacher/DashboardHeader.jsx
import React from 'react';
import { FiBell, FiHelpCircle, FiSettings } from 'react-icons/fi';

const DashboardHeader = () => {
  return (
    <header className="sticky top-0 z-10 bg-white border-b border-gray-200 shadow-sm">
      <div className="flex items-center justify-between p-4">
        <div>
          <h1 className="text-xl font-bold text-gray-800">Teacher Dashboard</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full relative">
            <FiBell size={20} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          
          <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
            <FiHelpCircle size={20} />
          </button>
          
          <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
            <FiSettings size={20} />
          </button>
          
          <div className="flex items-center">
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-10 h-10 mr-2" />
            <span className="font-medium text-gray-700 hidden md:inline">Dr. Jane Smith</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;