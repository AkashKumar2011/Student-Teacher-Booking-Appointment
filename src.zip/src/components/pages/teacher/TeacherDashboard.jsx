// src/pages/TeacherDashboard.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';
// import Sidebar from '../components/UI/Sidebar';
import ScheduleAppointment from '../teacher/ScheduleAppointment';
import ViewAllAppointments from '../teacher/ViewAllAppointments';
import ViewMessages from '../teacher/ViewMessages';
import DashboardHeader from '../teacher/DashboardHeader';


const TeacherDashboard = () => {
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-50">
      {/* <Sidebar /> */}
      
      <div className="flex-1 md:ml-64">
        <DashboardHeader />
        
        <main className="p-4 md:p-6">
          <Routes>
            <Route path="schedule" element={<ScheduleAppointment />} />
            <Route path="view-appointments" element={<ViewAllAppointments />} />
            <Route path="messages" element={<ViewMessages />} />
            <Route index element={<ScheduleAppointment />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default TeacherDashboard;