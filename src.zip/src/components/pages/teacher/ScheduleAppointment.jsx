// src/components/teacher/ScheduleAppointment.jsx
import React, { useState } from 'react';
import { FiCalendar, FiClock, FiPlus } from 'react-icons/fi';

const ScheduleAppointment = () => {
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [appointments, setAppointments] = useState([
    { id: 1, date: '2023-10-15', startTime: '09:00', endTime: '10:00', status: 'active' },
    { id: 2, date: '2023-10-16', startTime: '11:00', endTime: '12:00', status: 'active' },
  ]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!date || !startTime || !endTime) return;
    
    const newAppointment = {
      id: appointments.length + 1,
      date,
      startTime,
      endTime,
      status: 'active'
    };
    
    setAppointments([...appointments, newAppointment]);
    setDate('');
    setStartTime('');
    setEndTime('');
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-lg">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Schedule Appointment</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Schedule Form */}
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Add New Slot</h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="block text-gray-700 font-medium">Date</label>
              <div className="relative">
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full p-3 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  required
                />
                <FiCalendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-gray-700 font-medium">Start Time</label>
                <div className="relative">
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full p-3 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    required
                  />
                  <FiClock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="block text-gray-700 font-medium">End Time</label>
                <div className="relative">
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full p-3 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    required
                  />
                  <FiClock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                </div>
              </div>
            </div>
            
            <button
              type="submit"
              className="mt-4 w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-700 text-white font-medium rounded-lg shadow-md hover:from-indigo-700 hover:to-purple-800 transition-all flex items-center justify-center"
            >
              <FiPlus className="mr-2" />
              Add Appointment Slot
            </button>
          </form>
        </div>
        
        {/* Scheduled Slots */}
        <div>
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Your Scheduled Slots</h2>
          
          <div className="space-y-4">
            {appointments.map((appointment) => (
              <div 
                key={appointment.id}
                className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 rounded-lg flex justify-between items-center"
              >
                <div>
                  <p className="font-medium text-gray-800">{appointment.date}</p>
                  <p className="text-gray-600">
                    {appointment.startTime} - {appointment.endTime}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <button className="px-3 py-1 bg-rose-100 text-rose-700 rounded-md hover:bg-rose-200 transition-colors">
                    Cancel
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScheduleAppointment;