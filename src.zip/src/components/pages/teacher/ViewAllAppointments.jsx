// src/components/teacher/ViewAllAppointments.jsx
import React, { useState, useEffect } from 'react';
import { 
  FiCalendar, 
  FiClock, 
  FiFilter, 
  FiSearch, 
  FiChevronDown, 
  FiCheck, 
  FiX,
  FiUser,
  FiChevronUp,
  FiChevronLeft,
  FiChevronRight
} from 'react-icons/fi';

const ViewAllAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [filteredAppointments, setFilteredAppointments] = useState([]);
  const [filters, setFilters] = useState({
    status: 'all',
    dateRange: 'all',
    search: ''
  });
  const [sortConfig, setSortConfig] = useState({
    key: 'date',
    direction: 'desc'
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const [showFilters, setShowFilters] = useState(false);
  
  // Sample data - in a real app, this would come from Firebase
  const sampleAppointments = [
    {
      id: 1,
      student: 'John Doe',
      course: 'CS101',
      date: '2023-10-15',
      time: '09:00 - 10:00',
      purpose: 'Project discussion',
      status: 'approved',
      studentId: 'S001'
    },
    {
      id: 2,
      student: 'Sarah Johnson',
      course: 'CS201',
      date: '2023-10-16',
      time: '11:00 - 12:00',
      purpose: 'Midterm preparation',
      status: 'pending',
      studentId: 'S002'
    },
    {
      id: 3,
      student: 'Michael Chen',
      course: 'CS301',
      date: '2023-10-17',
      time: '14:00 - 15:00',
      purpose: 'Research guidance',
      status: 'cancelled',
      studentId: 'S003'
    },
    {
      id: 4,
      student: 'Emma Wilson',
      course: 'CS101',
      date: '2023-10-18',
      time: '10:00 - 11:00',
      purpose: 'Assignment clarification',
      status: 'approved',
      studentId: 'S004'
    },
    {
      id: 5,
      student: 'David Brown',
      course: 'CS201',
      date: '2023-10-19',
      time: '13:00 - 14:00',
      purpose: 'Final project review',
      status: 'pending',
      studentId: 'S005'
    },
    {
      id: 6,
      student: 'Olivia Garcia',
      course: 'CS301',
      date: '2023-10-20',
      time: '15:00 - 16:00',
      purpose: 'Thesis proposal',
      status: 'approved',
      studentId: 'S006'
    },
    {
      id: 7,
      student: 'James Wilson',
      course: 'CS101',
      date: '2023-10-21',
      time: '11:00 - 12:00',
      purpose: 'Exam preparation',
      status: 'cancelled',
      studentId: 'S007'
    },
    {
      id: 8,
      student: 'Sophia Martinez',
      course: 'CS201',
      date: '2023-10-22',
      time: '14:00 - 15:00',
      purpose: 'Project feedback',
      status: 'pending',
      studentId: 'S008'
    }
  ];
  
  // Initialize appointments
  useEffect(() => {
    setAppointments(sampleAppointments);
    setFilteredAppointments(sampleAppointments);
  }, []);
  
  // Apply filters and sorting
  useEffect(() => {
    let result = [...appointments];
    
    // Apply status filter
    if (filters.status !== 'all') {
      result = result.filter(app => app.status === filters.status);
    }
    
    // Apply date range filter (simplified for demo)
    if (filters.dateRange === 'upcoming') {
      const today = new Date().toISOString().split('T')[0];
      result = result.filter(app => app.date >= today);
    } else if (filters.dateRange === 'past') {
      const today = new Date().toISOString().split('T')[0];
      result = result.filter(app => app.date < today);
    }
    
    // Apply search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(app => 
        app.student.toLowerCase().includes(searchLower) ||
        app.course.toLowerCase().includes(searchLower) ||
        app.purpose.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply sorting
    if (sortConfig.key) {
      result.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    
    setFilteredAppointments(result);
    setCurrentPage(1); // Reset to first page when filters change
  }, [filters, appointments, sortConfig]);
  
  // Handle filter change
  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };
  
  // Handle sort
  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  // Pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentAppointments = filteredAppointments.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredAppointments.length / itemsPerPage);
  
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  
  // Get status color
  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-rose-100 text-rose-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Render sort indicator
  const renderSortIndicator = (key) => {
    if (sortConfig.key === key) {
      return sortConfig.direction === 'asc' ? 
        <FiChevronUp className="inline ml-1" /> : 
        <FiChevronDown className="inline ml-1" />;
    }
    return <FiChevronDown className="inline ml-1 opacity-30" />;
  };
  
  return (
    <div className="p-4 md:p-6 bg-white rounded-xl shadow-lg">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">All Appointments</h1>
        
        <div className="mt-4 md:mt-0 flex space-x-2">
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className="px-4 py-2 bg-gradient-to-r from-indigo-50 to-purple-50 text-indigo-700 font-medium rounded-lg flex items-center"
          >
            <FiFilter className="mr-2" />
            Filters
          </button>
          
          <div className="relative">
            <input
              type="text"
              placeholder="Search appointments..."
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              className="pl-10 pr-4 py-2 w-full md:w-64 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </div>
        </div>
      </div>
      
      {/* Filters Panel */}
      {showFilters && (
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-4 rounded-xl mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="all">All Statuses</option>
                <option value="approved">Approved</option>
                <option value="pending">Pending</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
              <select
                value={filters.dateRange}
                onChange={(e) => handleFilterChange('dateRange', e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="all">All Dates</option>
                <option value="upcoming">Upcoming</option>
                <option value="past">Past</option>
              </select>
            </div>
            
            <div className="flex items-end">
              <button
                onClick={() => {
                  setFilters({
                    status: 'all',
                    dateRange: 'all',
                    search: ''
                  });
                }}
                className="w-full py-2 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 font-medium rounded-lg hover:from-gray-200 hover:to-gray-300"
              >
                Reset Filters
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 rounded-xl border border-indigo-100">
          <p className="text-sm text-gray-600">Total Appointments</p>
          <p className="text-2xl font-bold text-indigo-700">{appointments.length}</p>
        </div>
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-100">
          <p className="text-sm text-gray-600">Approved</p>
          <p className="text-2xl font-bold text-green-700">
            {appointments.filter(a => a.status === 'approved').length}
          </p>
        </div>
        <div className="bg-gradient-to-r from-yellow-50 to-amber-50 p-4 rounded-xl border border-yellow-100">
          <p className="text-sm text-gray-600">Pending</p>
          <p className="text-2xl font-bold text-yellow-700">
            {appointments.filter(a => a.status === 'pending').length}
          </p>
        </div>
        <div className="bg-gradient-to-r from-rose-50 to-pink-50 p-4 rounded-xl border border-rose-100">
          <p className="text-sm text-gray-600">Cancelled</p>
          <p className="text-2xl font-bold text-rose-700">
            {appointments.filter(a => a.status === 'cancelled').length}
          </p>
        </div>
      </div>
      
      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full min-w-max">
          <thead>
            <tr className="bg-gradient-to-r from-indigo-50 to-purple-50">
              <th className="text-left p-4 text-gray-700 font-semibold">
                <button 
                  onClick={() => handleSort('student')}
                  className="flex items-center"
                >
                  Student {renderSortIndicator('student')}
                </button>
              </th>
              <th className="text-left p-4 text-gray-700 font-semibold">
                <button 
                  onClick={() => handleSort('course')}
                  className="flex items-center"
                >
                  Course {renderSortIndicator('course')}
                </button>
              </th>
              <th className="text-left p-4 text-gray-700 font-semibold">
                <button 
                  onClick={() => handleSort('date')}
                  className="flex items-center"
                >
                  Date & Time {renderSortIndicator('date')}
                </button>
              </th>
              <th className="text-left p-4 text-gray-700 font-semibold">
                Purpose
              </th>
              <th className="text-left p-4 text-gray-700 font-semibold">
                <button 
                  onClick={() => handleSort('status')}
                  className="flex items-center"
                >
                  Status {renderSortIndicator('status')}
                </button>
              </th>
              <th className="text-left p-4 text-gray-700 font-semibold">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {currentAppointments.map((appointment) => (
              <tr key={appointment.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="p-4">
                  <div className="flex items-center">
                    <div className="bg-gray-200 border-2 border-dashed rounded-xl w-10 h-10 mr-3" />
                    <div>
                      <span className="font-medium">{appointment.student}</span>
                      <p className="text-xs text-gray-500">{appointment.studentId}</p>
                    </div>
                  </div>
                </td>
                <td className="p-4 text-gray-600">{appointment.course}</td>
                <td className="p-4">
                  <div className="flex items-center text-gray-600">
                    <FiCalendar className="mr-2 text-indigo-500" />
                    <span className="mr-3">{appointment.date}</span>
                    <FiClock className="mr-2 text-indigo-500" />
                    <span>{appointment.time}</span>
                  </div>
                </td>
                <td className="p-4 text-gray-600 max-w-xs">{appointment.purpose}</td>
                <td className="p-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(appointment.status)}`}>
                    {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                  </span>
                </td>
                <td className="p-4">
                  {appointment.status === 'pending' && (
                    <div className="flex space-x-2">
                      <button className="px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200 transition-colors">
                        <FiCheck className="inline mr-1" /> Approve
                      </button>
                      <button className="px-3 py-1 bg-rose-100 text-rose-700 rounded-md hover:bg-rose-200 transition-colors">
                        <FiX className="inline mr-1" /> Cancel
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Mobile List */}
      <div className="md:hidden space-y-4">
        {currentAppointments.map((appointment) => (
          <div 
            key={appointment.id}
            className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 rounded-xl"
          >
            <div className="flex justify-between items-start mb-3">
              <div className="flex items-center">
                <div className="bg-gray-200 border-2 border-dashed rounded-xl w-12 h-12 mr-3" />
                <div>
                  <h3 className="font-medium text-gray-800">{appointment.student}</h3>
                  <p className="text-sm text-gray-600">{appointment.course}</p>
                </div>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="flex items-center text-gray-600">
                <FiCalendar className="mr-2 text-indigo-500" />
                <span>{appointment.date}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <FiClock className="mr-2 text-indigo-500" />
                <span>{appointment.time}</span>
              </div>
            </div>
            
            <div className="mb-3">
              <p className="text-sm text-gray-700 font-medium mb-1">Purpose</p>
              <p className="text-gray-600">{appointment.purpose}</p>
            </div>
            
            {appointment.status === 'pending' && (
              <div className="flex space-x-2">
                <button className="flex-1 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors">
                  <FiCheck className="inline mr-1" /> Approve
                </button>
                <button className="flex-1 py-2 bg-rose-100 text-rose-700 rounded-lg hover:bg-rose-200 transition-colors">
                  <FiX className="inline mr-1" /> Cancel
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Pagination */}
      {filteredAppointments.length > itemsPerPage && (
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between">
          <div className="text-sm text-gray-600 mb-4 sm:mb-0">
            Showing {indexOfFirstItem + 1} to {Math.min(indexOfLastItem, filteredAppointments.length)} of {filteredAppointments.length} appointments
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => currentPage > 1 && paginate(currentPage - 1)}
              disabled={currentPage === 1}
              className={`p-2 rounded-lg ${currentPage === 1 ? 'bg-gray-100 text-gray-400' : 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200'}`}
            >
              <FiChevronLeft />
            </button>
            
            {[...Array(totalPages)].map((_, i) => (
              <button
                key={i}
                onClick={() => paginate(i + 1)}
                className={`w-10 h-10 rounded-lg ${
                  currentPage === i + 1 
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-700 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {i + 1}
              </button>
            ))}
            
            <button
              onClick={() => currentPage < totalPages && paginate(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`p-2 rounded-lg ${currentPage === totalPages ? 'bg-gray-100 text-gray-400' : 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200'}`}
            >
              <FiChevronRight />
            </button>
          </div>
        </div>
      )}
      
      {filteredAppointments.length === 0 && (
        <div className="text-center py-12">
          <div className="bg-gray-100 border-2 border-dashed rounded-xl w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <FiCalendar className="text-gray-400 text-2xl" />
          </div>
          <h3 className="text-lg font-medium text-gray-700 mb-2">No appointments found</h3>
          <p className="text-gray-500">Try adjusting your filters or search terms</p>
          <button
            onClick={() => setFilters({
              status: 'all',
              dateRange: 'all',
              search: ''
            })}
            className="mt-4 px-4 py-2 bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-700 font-medium rounded-lg"
          >
            Reset all filters
          </button>
        </div>
      )}
    </div>
  );
};

export default ViewAllAppointments;