import { useState, useEffect } from 'react';
import { db } from '../../../firebase/config';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  doc, 
  updateDoc,
  orderBy
} from 'firebase/firestore';
import { useAuth } from '../../../context/AuthContext';
import { 
  FiArrowLeft, 
  FiHome, 
  FiClock, 
  FiCalendar, 
  FiMessageSquare, 
  FiCheck, 
  FiX, 
  FiTrash2,
  FiSearch,
  FiFilter,
  FiChevronDown,
  FiChevronUp,
  FiRefreshCw
} from 'react-icons/fi';
import { useNavigate, useLocation } from 'react-router-dom';
import { toast } from 'react-hot-toast';

export default function MyAppointments() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [appointments, setAppointments] = useState([]);
  const [filteredAppointments, setFilteredAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    if (!currentUser) return;
    
    setLoading(true);
    const q = query(
      collection(db, 'appointments'),
      where('studentId', '==', currentUser.uid),
      orderBy('date', 'desc'),
      orderBy('timeSlot', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const appointmentsData = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        // Ensure date is in YYYY-MM-DD format for proper sorting
        const formattedDate = data.date instanceof Date 
          ? data.date.toISOString().split('T')[0]
          : data.date;
        
        appointmentsData.push({ 
          id: doc.id, 
          ...data,
          date: formattedDate
        });
      });
      
      setAppointments(appointmentsData);
      setFilteredAppointments(appointmentsData);
      setLoading(false);
      setIsRefreshing(false);
    }, (error) => {
      console.error("Firestore error:", error);
      toast.error('Error loading appointments: ' + error.message);
      setLoading(false);
      setIsRefreshing(false);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Apply filters
  useEffect(() => {
    let result = [...appointments];
    
    // Apply status filter
    if (statusFilter !== 'all') {
      result = result.filter(appt => appt.status === statusFilter);
    }
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(appt => 
        (appt.teacherName?.toLowerCase().includes(term)) ||
        (appt.teacherDepartment?.toLowerCase().includes(term)) ||
        (appt.purpose?.toLowerCase().includes(term))
      );
    }
    
    setFilteredAppointments(result);
  }, [appointments, statusFilter, searchTerm]);

  // Set initial filter from URL
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const status = params.get('status');
    if (status && ['pending', 'approved', 'rejected', 'cancelled', 'upcoming'].includes(status)) {
      setStatusFilter(status === 'upcoming' ? 'approved' : status);
    }
  }, [location]);

  const handleCancelAppointment = async (appointmentId) => {
    if (!window.confirm('Are you sure you want to cancel this appointment?')) return;
    
    try {
      setLoading(true);
      const appointmentRef = doc(db, 'appointments', appointmentId);
      await updateDoc(appointmentRef, { 
        status: 'cancelled',
        cancelledAt: new Date().toISOString()
      });
      toast.success('Appointment cancelled successfully!');
    } catch (error) {
      toast.error('Error cancelling appointment: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const refreshData = () => {
    setIsRefreshing(true);
    // Simulate refresh by re-fetching data
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      cancelled: 'bg-gray-100 text-gray-800'
    };
    
    const statusIcons = {
      pending: <FiClock className="mr-1" />,
      approved: <FiCheck className="mr-1" />,
      rejected: <FiX className="mr-1" />,
      cancelled: <FiX className="mr-1" />
    };
    
    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-full flex items-center ${statusClasses[status]}`}>
        {statusIcons[status]}
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return dateString; // Return raw string if parsing fails
    }
  };

  const formatTime = (timeSlot) => {
    return timeSlot.split('-').join(' to ');
  };

  const isUpcoming = (appointment) => {
    if (appointment.status !== 'approved') return false;
    const now = new Date();
    try {
      const [startTime] = appointment.timeSlot.split('-');
      const apptDate = new Date(`${appointment.date}T${startTime}`);
      return apptDate > now;
    } catch {
      return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 px-6 py-4 rounded-xl shadow-lg mb-6 flex justify-between items-center">
          <div className="flex items-center">
            <FiCalendar className="text-white text-2xl mr-3" />
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-white">My Appointments</h1>
              <p className="text-blue-100 text-sm">Manage your scheduled appointments with teachers</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => navigate(-1)}
              className="p-2 text-white hover:bg-indigo-700 rounded-full transition-colors"
              title="Go back"
            >
              <FiArrowLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => navigate('/student')}
              className="p-2 text-white hover:bg-indigo-700 rounded-full transition-colors"
              title="Go to dashboard"
            >
              <FiHome className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FiSearch className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search by teacher, department or purpose..."
                className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors flex items-center"
              >
                <FiFilter className="mr-2" />
                Filters {showFilters ? <FiChevronUp className="ml-1" /> : <FiChevronDown className="ml-1" />}
              </button>
              
              <button
                onClick={refreshData}
                disabled={isRefreshing}
                className={`px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg flex items-center ${
                  isRefreshing ? 'opacity-75' : 'hover:from-green-600 hover:to-emerald-700'
                } transition-colors`}
              >
                {isRefreshing ? (
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <FiRefreshCw className="mr-2" />
                )}
                Refresh
              </button>
            </div>
          </div>
          
          {/* Filters Panel */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t border-gray-200 grid grid-cols-2 md:grid-cols-4 gap-4">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-2 rounded-lg text-sm ${
                  statusFilter === 'all' 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                All Appointments
              </button>
              <button
                onClick={() => setStatusFilter('pending')}
                className={`px-3 py-2 rounded-lg text-sm flex items-center ${
                  statusFilter === 'pending' 
                    ? 'bg-yellow-500 text-white' 
                    : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
                }`}
              >
                <FiClock className="mr-1" /> Pending
              </button>
              <button
                onClick={() => setStatusFilter('approved')}
                className={`px-3 py-2 rounded-lg text-sm flex items-center ${
                  statusFilter === 'approved' 
                    ? 'bg-green-500 text-white' 
                    : 'bg-green-100 text-green-800 hover:bg-green-200'
                }`}
              >
                <FiCheck className="mr-1" /> Approved
              </button>
              <button
                onClick={() => setStatusFilter('rejected')}
                className={`px-3 py-2 rounded-lg text-sm flex items-center ${
                  statusFilter === 'rejected' 
                    ? 'bg-red-500 text-white' 
                    : 'bg-red-100 text-red-800 hover:bg-red-200'
                }`}
              >
                <FiX className="mr-1" /> Rejected
              </button>
            </div>
          )}
        </div>
        
        {/* Appointments List */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {loading ? (
            <div className="p-8 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading your appointments...</p>
            </div>
          ) : filteredAppointments.length === 0 ? (
            <div className="p-8 text-center">
              <div className="bg-gradient-to-r from-indigo-100 to-purple-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <FiCalendar className="text-indigo-600 text-2xl" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-1">No appointments found</h3>
              <p className="text-gray-500 mb-4">
                {appointments.length === 0 
                  ? "You haven't booked any appointments yet" 
                  : "No appointments match your search criteria"}
              </p>
              <button
                onClick={() => {
                  setStatusFilter('all');
                  setSearchTerm('');
                }}
                className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-md mr-3"
              >
                Clear Filters
              </button>
              <button
                onClick={() => navigate('/student/search-teachers')}
                className="px-4 py-2 border border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-50 transition-all"
              >
                Find a Teacher
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teacher</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Purpose</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredAppointments.map(appointment => (
                    <tr 
                      key={appointment.id} 
                      className={`hover:bg-gray-50 transition-colors ${isUpcoming(appointment) ? 'bg-blue-50' : ''}`}
                      id={`appt-${appointment.id}`}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 bg-gradient-to-r from-indigo-100 to-blue-100 rounded-full flex items-center justify-center">
                            <FiUser className="text-indigo-600" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{appointment.teacherName}</div>
                            <div className="text-sm text-gray-500">{appointment.teacherDepartment}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {formatDate(appointment.date)}
                        </div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <FiClock className="mr-1 text-indigo-500" />
                          {formatTime(appointment.timeSlot)}
                        </div>
                        {isUpcoming(appointment) && (
                          <span className="inline-block mt-1 bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                            Upcoming
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-500 max-w-xs truncate flex items-start">
                          <FiMessageSquare className="mr-2 mt-0.5 flex-shrink-0 text-indigo-500" />
                          {appointment.purpose}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(appointment.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-4">
                          <button
                            onClick={() => navigate(`/student/message-system?teacherId=${appointment.teacherId}`)}
                            className="text-indigo-600 hover:text-indigo-900 transition-colors"
                            disabled={loading}
                          >
                            Message
                          </button>
                          {(appointment.status === 'pending' || (appointment.status === 'approved' && isUpcoming(appointment))) && (
                            <button
                              onClick={() => handleCancelAppointment(appointment.id)}
                              className="text-red-600 hover:text-red-900 transition-colors flex items-center"
                              disabled={loading}
                            >
                              <FiTrash2 className="mr-1" /> Cancel
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        
        {/* Stats Summary */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-indigo-600 to-purple-600 text-white rounded-lg shadow p-4">
            <div className="text-sm">Total Appointments</div>
            <div className="text-2xl font-bold">{appointments.length}</div>
          </div>
          <div className="bg-gradient-to-br from-amber-500 to-orange-500 text-white rounded-lg shadow p-4">
            <div className="text-sm">Pending</div>
            <div className="text-2xl font-bold">
              {appointments.filter(a => a.status === 'pending').length}
            </div>
          </div>
          <div className="bg-gradient-to-br from-green-500 to-emerald-500 text-white rounded-lg shadow p-4">
            <div className="text-sm">Approved</div>
            <div className="text-2xl font-bold">
              {appointments.filter(a => a.status === 'approved').length}
            </div>
          </div>
          <div className="bg-gradient-to-br from-red-500 to-pink-500 text-white rounded-lg shadow p-4">
            <div className="text-sm">Rejected/Cancelled</div>
            <div className="text-2xl font-bold">
              {appointments.filter(a => a.status === 'rejected' || a.status === 'cancelled').length}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}