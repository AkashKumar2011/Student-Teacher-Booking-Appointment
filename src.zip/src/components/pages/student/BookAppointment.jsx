import { useState, useEffect } from 'react';
import { db } from '../../../firebase/config';
import { collection, addDoc, query, where, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { useAuth } from '../../../context/AuthContext';
import { toast } from 'react-hot-toast';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  FiArrowLeft, 
  FiHome, 
  FiCalendar, 
  FiClock, 
  FiMessageSquare, 
  FiUser, 
  FiBook,
  FiCheck,
  FiX
} from 'react-icons/fi';

export default function BookAppointment() {
  const { currentUser } = useAuth();
  const { teacherId } = useParams();
  const navigate = useNavigate();
  const [date, setDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [purpose, setPurpose] = useState('');
  const [loading, setLoading] = useState(false);
  const [availableSlots, setAvailableSlots] = useState([]);
  const [teacher, setTeacher] = useState(null);
  const [validationErrors, setValidationErrors] = useState({});
  const [isFetching, setIsFetching] = useState(true);

  // Fetch teacher details
  useEffect(() => {
    const fetchTeacher = async () => {
      try {
        const teacherDoc = await getDoc(doc(db, 'users', teacherId));
        if (teacherDoc.exists()) {
          setTeacher({
            id: teacherDoc.id,
            ...teacherDoc.data()
          });
        } else {
          toast.error('Teacher not found');
          navigate('/student/search-teachers');
        }
      } catch (error) {
        toast.error('Error fetching teacher details');
        console.error(error);
        navigate('/student/search-teachers');
      } finally {
        setIsFetching(false);
      }
    };

    if (teacherId) {
      fetchTeacher();
    } else {
      navigate('/student/search-teachers');
    }
  }, [teacherId, navigate]);

  // Fetch available time slots
  useEffect(() => {
    if (!teacherId) return;

    const q = query(
      collection(db, 'availability'),
      where('teacherId', '==', teacherId),
      where('status', '==', 'available')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const slots = [];
      const now = new Date();
      
      snapshot.forEach(doc => {
        const slot = doc.data();
        const slotDate = new Date(slot.date);
        
        // Only include future slots
        if (slotDate >= now) {
          slots.push({
            id: doc.id,
            ...slot,
            formattedDate: slotDate.toLocaleDateString('en-US', {
              weekday: 'short',
              month: 'short',
              day: 'numeric'
            })
          });
        }
      });
      
      // Sort by date then by time
      slots.sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        if (dateA - dateB !== 0) return dateA - dateB;
        return a.startTime.localeCompare(b.startTime);
      });
      
      setAvailableSlots(slots);
    });

    return () => unsubscribe();
  }, [teacherId]);

  const validateForm = () => {
    const errors = {};
    
    if (!date) errors.date = 'Please select a date';
    if (!timeSlot) errors.timeSlot = 'Please select a time slot';
    if (!purpose.trim()) errors.purpose = 'Please enter appointment purpose';
    if (purpose.length > 500) errors.purpose = 'Purpose should be less than 500 characters';
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    if (!teacherId || !currentUser?.uid) {
      toast.error('Invalid request');
      return;
    }
    
    setLoading(true);
    try {
      // Create appointment
      await addDoc(collection(db, 'appointments'), {
        studentId: currentUser.uid,
        studentName: currentUser.displayName || currentUser.email,
        teacherId: teacherId,
        teacherName: teacher?.name || 'Teacher',
        date: date,
        timeSlot: timeSlot,
        purpose: purpose,
        status: 'pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      
      toast.success('Appointment requested successfully!');
      navigate('/student/my-appointments');
    } catch (error) {
      toast.error('Error requesting appointment: ' + error.message);
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (isFetching) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate(-1)}
              className="p-2 bg-gradient-to-r from-indigo-100 to-blue-100 text-indigo-600 rounded-lg hover:from-indigo-200 hover:to-blue-200 transition-all shadow-sm"
            >
              <FiArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center">
                <FiCalendar className="mr-3 text-indigo-600" />
                Book Appointment
              </h1>
              <p className="text-gray-600">Schedule a meeting with your teacher</p>
            </div>
          </div>
          <button
            onClick={() => navigate('/student')}
            className="p-2 bg-gradient-to-r from-indigo-100 to-blue-100 text-indigo-600 rounded-lg hover:from-indigo-200 hover:to-blue-200 transition-all shadow-sm"
          >
            <FiHome className="w-5 h-5" />
          </button>
        </div>

        {/* Teacher Info */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex-shrink-0 h-16 w-16 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full flex items-center justify-center shadow-md">
              <FiUser className="text-indigo-600 text-2xl" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">{teacher?.name || 'Teacher'}</h2>
              <div className="flex flex-wrap gap-2 mt-2">
                {teacher?.department && (
                  <span className="bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-800 px-3 py-1 rounded-full text-xs flex items-center">
                    <FiBook className="mr-1" /> {teacher.department}
                  </span>
                )}
                {teacher?.subject && (
                  <span className="bg-gradient-to-r from-purple-100 to-fuchsia-100 text-purple-800 px-3 py-1 rounded-full text-xs">
                    {teacher.subject}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Appointment Form */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700 flex items-center">
                <FiCalendar className="mr-2 text-indigo-500" /> Date
              </label>
              <select
                value={date}
                onChange={(e) => {
                  setDate(e.target.value);
                  setTimeSlot('');
                }}
                className={`mt-1 block w-full px-4 py-2.5 border ${
                  validationErrors.date ? 'border-red-300' : 'border-gray-300'
                } rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all`}
              >
                <option value="">Select a date</option>
                {[...new Set(availableSlots.map(slot => slot.date))].map((date, index) => (
                  <option key={index} value={date}>
                    {new Date(date).toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </option>
                ))}
              </select>
              {validationErrors.date && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.date}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700 flex items-center">
                <FiClock className="mr-2 text-indigo-500" /> Time Slot
              </label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                disabled={!date}
                className={`mt-1 block w-full px-4 py-2.5 border ${
                  validationErrors.timeSlot ? 'border-red-300' : 'border-gray-300'
                } rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all`}
              >
                <option value="">Select a time slot</option>
                {availableSlots
                  .filter(slot => slot.date === date)
                  .map((slot, index) => (
                    <option key={index} value={slot.timeSlot}>
                      {slot.timeSlot}
                    </option>
                  ))}
              </select>
              {validationErrors.timeSlot && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.timeSlot}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700 flex items-center">
                <FiMessageSquare className="mr-2 text-indigo-500" /> Purpose
              </label>
              <textarea
                rows={4}
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className={`mt-1 block w-full px-4 py-2.5 border ${
                  validationErrors.purpose ? 'border-red-300' : 'border-gray-300'
                } rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all`}
                placeholder="Briefly describe the purpose of your appointment..."
              />
              <div className="flex justify-between items-center">
                {validationErrors.purpose && (
                  <p className="text-sm text-red-600">{validationErrors.purpose}</p>
                )}
                <span className={`text-xs ${purpose.length > 500 ? 'text-red-600' : 'text-gray-500'}`}>
                  {purpose.length}/500
                </span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg flex items-center justify-center disabled:opacity-75 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    <FiCalendar className="mr-2" /> Request Appointment
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}