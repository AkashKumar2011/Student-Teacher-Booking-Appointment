import { useState, useEffect, useRef } from 'react';
import { db } from '../../../firebase/config';
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  addDoc,
  serverTimestamp,
  doc,
  getDoc,
  updateDoc
} from 'firebase/firestore';
import { useAuth } from '../../../context/AuthContext';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  FiArrowLeft, 
  FiHome, 
  FiSend, 
  FiMessageSquare,
  FiUser,
  FiClock,
  FiMail
} from 'react-icons/fi';
import { toast } from 'react-hot-toast';

export default function SendMessage() {
  const { currentUser } = useAuth();
  const { teacherId } = useParams();
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [teacher, setTeacher] = useState(null);
  const messagesEndRef = useRef(null);
  const [isFetching, setIsFetching] = useState(true);

  // Fetch teacher details
  useEffect(() => {
    const fetchTeacher = async () => {
      try {
        const teacherDoc = await getDoc(doc(db, 'users', teacherId));
        if (teacherDoc.exists()) {
          setTeacher({
            id: teacherDoc.id,
            ...teacherDoc.data()
          });
        } else {
          toast.error('Teacher not found');
          navigate('/student/search-teachers');
        }
      } catch (error) {
        toast.error('Error fetching teacher details');
        console.error(error);
        navigate('/student/search-teachers');
      } finally {
        setIsFetching(false);
      }
    };

    if (teacherId) {
      fetchTeacher();
    } else {
      navigate('/student/search-teachers');
    }
  }, [teacherId, navigate]);

  // Fetch messages
  useEffect(() => {
    if (!teacherId || !currentUser?.uid) return;

    const q = query(
      collection(db, 'messages'),
      where('participants', 'array-contains', currentUser.uid),
      orderBy('createdAt', 'asc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messagesData = [];
      snapshot.forEach(doc => {
        const message = doc.data();
        // Only include messages between current user and selected teacher
        if (message.participants.includes(teacherId)) {
          messagesData.push({
            id: doc.id,
            ...message,
            isCurrentUser: message.senderId === currentUser.uid
          });
          
          // Mark as read if current user is the receiver
          if (message.receiverId === currentUser.uid && message.status !== 'read') {
            updateDoc(doc.ref, { status: 'read' });
          }
        }
      });
      setMessages(messagesData);
    });

    return () => unsubscribe();
  }, [teacherId, currentUser]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!newMessage.trim()) {
      toast.error('Message cannot be empty');
      return;
    }
    if (!teacherId || !currentUser?.uid) {
      toast.error('Invalid request');
      return;
    }

    setLoading(true);
    try {
      await addDoc(collection(db, 'messages'), {
        content: newMessage,
        senderId: currentUser.uid,
        senderName: currentUser.displayName || currentUser.email,
        receiverId: teacherId,
        receiverName: teacher?.name || 'Teacher',
        participants: [currentUser.uid, teacherId],
        status: 'unread',
        createdAt: serverTimestamp()
      });
      setNewMessage('');
    } catch (error) {
      toast.error('Failed to send message: ' + error.message);
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (isFetching) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate(-1)}
              className="p-2 bg-gradient-to-r from-indigo-100 to-blue-100 text-indigo-600 rounded-lg hover:from-indigo-200 hover:to-blue-200 transition-all shadow-sm"
            >
              <FiArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center">
                <FiMessageSquare className="mr-3 text-indigo-600" />
                Messages
              </h1>
              <div className="flex items-center mt-1">
                <FiUser className="text-indigo-500 mr-1" />
                <span className="text-gray-600">
                  Conversation with <span className="font-medium">{teacher?.name || 'Teacher'}</span>
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={() => navigate('/student')}
            className="p-2 bg-gradient-to-r from-indigo-100 to-blue-100 text-indigo-600 rounded-lg hover:from-indigo-200 hover:to-blue-200 transition-all shadow-sm"
          >
            <FiHome className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Container */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
          {/* Messages List */}
          <div className="h-96 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8">
                <div className="bg-gradient-to-r from-indigo-100 to-purple-100 w-20 h-20 rounded-full flex items-center justify-center mb-4">
                  <FiMessageSquare className="text-indigo-600 text-2xl" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">No messages yet</h3>
                <p className="text-gray-500">Start the conversation with {teacher?.name || 'the teacher'}</p>
              </div>
            ) : (
              messages.map((message) => (
                <div 
                  key={message.id} 
                  className={`flex ${message.isCurrentUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-xs md:max-w-md rounded-lg p-3 ${
                      message.isCurrentUser 
                        ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white' 
                        : 'bg-gradient-to-r from-gray-100 to-blue-50 text-gray-800'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <div className={`text-xs mt-1 flex items-center ${
                      message.isCurrentUser ? 'text-indigo-100' : 'text-gray-500'
                    }`}>
                      <FiClock className="mr-1" />
                      {message.createdAt?.toDate 
                        ? message.createdAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        : 'Just now'}
                    </div>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
          
          {/* Message Input */}
          <div className="border-t border-gray-200 p-4 bg-gray-50">
            <form onSubmit={handleSendMessage} className="flex items-center">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-l-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={!newMessage.trim() || loading}
                className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-r-lg hover:from-indigo-700 hover:to-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
              >
                {loading ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <>
                    <FiSend className="mr-2" /> Send
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}