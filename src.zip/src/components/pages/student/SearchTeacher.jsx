import { useState, useEffect } from 'react';
import { db } from '../../../firebase/config';
import { 
  collection, 
  query, 
  where, 
  onSnapshot,
  getDocs  // Added missing import
} from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { 
  FiArrowLeft, 
  FiHome, 
  FiSearch, 
  FiUser, 
  FiBook, 
  FiCalendar, 
  FiMail,
  FiFilter,
  FiX,
  FiRefreshCw
} from 'react-icons/fi';
import { toast } from 'react-hot-toast';
import { useAuth } from '../../../context/AuthContext';

export default function SearchTeacher() {
  const [teachers, setTeachers] = useState([]);
  const [filteredTeachers, setFilteredTeachers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  // Fetch teachers data
  useEffect(() => {
    const fetchTeachers = async () => {
      try {
        setLoading(true);
        setIsRefreshing(true);
        
        const q = query(
          collection(db, 'teachers'),
          where('role', '==', 'teacher'),
          where('status', '==', 'active')
        );
        
        const unsubscribe = onSnapshot(q, async (snapshot) => {
          const teachersData = [];
          
          for (const docSnapshot of snapshot.docs) {
            const teacherData = docSnapshot.data();
            // Get additional availability data
            const availabilityQuery = query(
              collection(db, 'availability'),
              where('teacherId', '==', docSnapshot.id),
              where('status', '==', 'active')
            );
            
            const availabilitySnapshot = await getDocs(availabilityQuery);
            const status = !availabilitySnapshot.empty;
            
            teachersData.push({ 
              id: docSnapshot.id,
              ...teacherData,
              status
            });
          }
          
          setTeachers(teachersData);
          setFilteredTeachers(teachersData);
          setLoading(false);
          setIsRefreshing(false);
        });

        return () => unsubscribe();
      } catch (err) {
        setError('Failed to load teachers. Please try again later.');
        setLoading(false);
        setIsRefreshing(false);
        console.error('Error fetching teachers:', err);
      }
    };

    fetchTeachers();
  }, []);

  // Apply filters whenever search terms or filters change
  useEffect(() => {
    const filtered = teachers.filter(teacher => {
      const term = searchTerm.toLowerCase();
      const matchesSearch = (
        (teacher.name?.toLowerCase().includes(term)) ||
        (teacher.email?.toLowerCase().includes(term)) ||
        (teacher.department?.toLowerCase().includes(term)) ||
        (teacher.subjects?.some(subj => subj.toLowerCase().includes(term)))
      );
      
      const matchesDepartment = !departmentFilter || 
        teacher.department?.toLowerCase() === departmentFilter.toLowerCase();
      
      const matchesSubject = !subjectFilter || 
        teacher.subjects?.some(subj => subj.toLowerCase() === subjectFilter.toLowerCase());
      
      return matchesSearch && matchesDepartment && matchesSubject;
    });
    
    setFilteredTeachers(filtered);
  }, [searchTerm, departmentFilter, subjectFilter, teachers]);

  const departments = [...new Set(
    teachers.map(teacher => teacher.department).filter(Boolean)
  )].sort();

  const subjects = [...new Set(
    teachers.flatMap(teacher => teacher.subjects || []).filter(Boolean)
  )].sort();

  const handleRefresh = () => {
    setIsRefreshing(true);
    window.location.reload();
  };

  const clearFilters = () => {
    setSearchTerm('');
    setDepartmentFilter('');
    setSubjectFilter('');
  };

  if (loading && !isRefreshing) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
        <div className="max-w-6xl mx-auto flex flex-col items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500 mb-4"></div>
          <p className="text-gray-600">Loading available teachers...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
        <div className="max-w-6xl mx-auto bg-white rounded-xl shadow-lg p-6 text-center">
          <div className="bg-gradient-to-r from-red-100 to-pink-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <FiUser className="text-red-600 text-2xl" />
          </div>
          <h2 className="text-xl font-bold text-red-600 mb-2">Connection Error</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <div className="flex justify-center space-x-4">
            <button
              onClick={handleRefresh}
              className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-md"
            >
              Try Again
            </button>
            <button
              onClick={() => navigate(currentUser ? '/student' : '/')}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all"
            >
              {currentUser ? 'Go to Dashboard' : 'Return Home'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 mt-9 p-4 md:p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 px-6 py-4 rounded-xl shadow-lg mb-6 flex justify-between items-center">
          <div className="flex items-center">
            <FiUser className="text-white text-2xl mr-3" />
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-white">Find a Teacher</h1>
              <p className="text-blue-100 text-sm">Search and book appointments with available teachers</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => navigate(-1)}
              className="p-2 text-white hover:bg-indigo-700 rounded-full transition-colors"
              title="Go back"
            >
              <FiArrowLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => navigate(currentUser ? '/student' : '/')}
              className="p-2 text-white hover:bg-indigo-700 rounded-full transition-colors"
              title="Go to dashboard"
            >
              <FiHome className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FiSearch className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search by name, department or subject..."
                className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`px-4 py-2 rounded-lg flex items-center ${
                  showFilters 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } transition-all`}
              >
                <FiFilter className="mr-2" />
                Filters
              </button>
              
              {(departmentFilter || subjectFilter) && (
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-all flex items-center"
                >
                  <FiX className="mr-1" />
                  Clear
                </button>
              )}
              
              <button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className={`px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg flex items-center ${
                  isRefreshing ? 'opacity-75' : 'hover:from-green-600 hover:to-emerald-700'
                } transition-all`}
              >
                {isRefreshing ? (
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <FiRefreshCw className="mr-2" />
                )}
                Refresh
              </button>
            </div>
          </div>
          
          {/* Expanded Filters */}
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                <select
                  value={departmentFilter}
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="">All Departments</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                <select
                  value={subjectFilter}
                  onChange={(e) => setSubjectFilter(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="">All Subjects</option>
                  {subjects.map(subj => (
                    <option key={subj} value={subj}>{subj}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Teachers List */}
        {filteredTeachers.length === 0 ? (
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="bg-gradient-to-r from-indigo-100 to-purple-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <FiUser className="text-indigo-600 text-2xl" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">No teachers found</h3>
            <p className="text-gray-500 mb-4">
              {teachers.length === 0 
                ? "There are currently no active teachers in the system" 
                : "No teachers match your search criteria"}
            </p>
            <button
              onClick={clearFilters}
              className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-md"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTeachers.map(teacher => (
              <div key={teacher.id} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 h-12 w-12 bg-gradient-to-br from-indigo-100 to-blue-100 rounded-full flex items-center justify-center">
                      <FiUser className="text-indigo-600 text-xl" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-bold text-gray-900 truncate">
                        {teacher.fullName || 'Unknown Teacher'}
                      </h3>
                      <div className="flex items-center mt-1 space-x-2">
                        {teacher.status ? (
                          <span className="inline-block px-2 py-1 text-xs font-medium bg-green-200 text-green-800 rounded-full">
                            Available
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-1 text-xs font-medium bg-gray-200 text-gray-800 rounded-full">
                            Unavailable
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 space-y-3">
                    <div className="flex items-center text-sm">
                      <FiMail className="text-indigo-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-600 truncate">
                        <span className="font-medium text-gray-700">Email:</span> {teacher.email}
                      </span>
                    </div>

                    <div className="flex items-center text-sm">
                      <FiBook className="text-indigo-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-600">
                        <span className="font-medium text-gray-700">Department:</span> {teacher.department || 'N/A'}
                      </span>
                    </div>
                    
                    <div className="flex items-start text-sm">
                      <FiBook className="text-indigo-500 mr-3 mt-1 flex-shrink-0" />
                      <div>
                        <span className="font-medium text-gray-700">Subjects:</span>
                        <div className="flex flex-wrap flex-row gap-1 mt-1">
                          {teacher.subjects?.length > 0 ? (
                            teacher.subjects.map(subject => (
                              <span key={subject} className="bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full text-xs">
                                {subject}
                              </span>
                            ))
                          ) : (
                            <span className="text-gray-500 text-xs">No subjects listed</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end space-x-3">
                    <button
                      onClick={() => navigate(`/student/book-appointment/${teacher.id}`)}
                      disabled={!teacher.status}
                      className={`px-4 py-2 rounded-lg flex items-center shadow-sm ${
                        teacher.status
                          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700'
                          : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                      } transition-colors`}
                    >
                      <FiCalendar className="mr-2" /> Book
                    </button>
                    <button
                      onClick={() => navigate(`/student/send-message/${teacher.id}`)}
                      className="px-4 py-2 border border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors flex items-center"
                    >
                      <FiMail className="mr-2" /> Message
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}