import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  FiHome, 
  FiCalendar, 
  FiUser, 
  FiMessageSquare, 
  FiBook,
  FiClock,
  FiCheck,
  FiX,
  FiChevronRight
} from 'react-icons/fi';
import { useAuth } from '../../../context/AuthContext';
import { db } from '../../../firebase/config';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { toast } from 'react-hot-toast';

export default function StudentDashboard() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    upcoming: 0,
    pending: 0,
    approved: 0,
    rejected: 0
  });
  const [upcomingAppointments, setUpcomingAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser?.uid) return;
    
    // Fetch appointment statistics
    const appointmentsQuery = query(
      collection(db, 'appointments'),
      where('studentId', '==', currentUser.uid)
    );
    
    const unsubscribeAppointments = onSnapshot(appointmentsQuery, (snapshot) => {
      const now = new Date();
      let upcoming = 0;
      let pending = 0;
      let approved = 0;
      let rejected = 0;
      
      snapshot.forEach(doc => {
        const appt = doc.data();
        try {
          const [startTime] = appt.timeSlot.split('-');
          const apptDate = new Date(`${appt.date}T${startTime}`);
          
          if (appt.status === 'pending') pending++;
          if (appt.status === 'approved') approved++;
          if (appt.status === 'rejected') rejected++;
          if (appt.status === 'approved' && apptDate > now) upcoming++;
        } catch (e) {
          console.error("Error processing appointment:", e);
        }
      });
      
      setStats({ upcoming, pending, approved, rejected });
    }, (error) => {
      console.error("Firestore error:", error);
      toast.error('Error loading appointments: ' + error.message);
    });
    
    // Fetch upcoming appointments (max 3)
    const upcomingQuery = query(
      collection(db, 'appointments'),
      where('studentId', '==', currentUser.uid),
      where('status', '==', 'approved')
    );
    
    const unsubscribeUpcoming = onSnapshot(upcomingQuery, (snapshot) => {
      const now = new Date();
      const upcoming = [];
      
      snapshot.forEach(doc => {
        const appt = doc.data();
        try {
          const [startTime] = appt.timeSlot.split('-');
          const apptDate = new Date(`${appt.date}T${startTime}`);
          
          if (apptDate > now) {
            upcoming.push({
              id: doc.id,
              ...appt,
              dateObj: apptDate
            });
          }
        } catch (e) {
          console.error("Error processing appointment:", e);
        }
      });
      
      // Sort by date and time
      upcoming.sort((a, b) => a.dateObj - b.dateObj);
      // Take only the next 3 appointments
      setUpcomingAppointments(upcoming.slice(0, 3));
      setLoading(false);
    }, (error) => {
      console.error("Firestore error:", error);
      toast.error('Error loading upcoming appointments: ' + error.message);
      setLoading(false);
    });
    
    return () => {
      unsubscribeAppointments();
      unsubscribeUpcoming();
    };
  }, [currentUser]);

  const dashboardCards = [
    {
      title: "Upcoming Appointments",
      value: stats.upcoming,
      icon: <FiCalendar className="text-3xl" />,
      bg: "bg-gradient-to-br from-indigo-600 to-purple-600",
      textColor: "text-white",
      action: () => navigate('/student/my-appointments?status=upcoming')
    },
    {
      title: "Pending Requests",
      value: stats.pending,
      icon: <FiClock className="text-3xl" />,
      bg: "bg-gradient-to-br from-amber-500 to-orange-500",
      textColor: "text-white",
      action: () => navigate('/student/my-appointments?status=pending')
    },
    {
      title: "Approved Appointments",
      value: stats.approved,
      icon: <FiCheck className="text-3xl" />,
      bg: "bg-gradient-to-br from-green-500 to-emerald-500",
      textColor: "text-white",
      action: () => navigate('/student/my-appointments?status=approved')
    },
    {
      title: "Rejected Requests",
      value: stats.rejected,
      icon: <FiX className="text-3xl" />,
      bg: "bg-gradient-to-br from-red-500 to-pink-500",
      textColor: "text-white",
      action: () => navigate('/student/my-appointments?status=rejected')
    }
  ];

  const quickActions = [
    {
      title: "Find Teachers",
      icon: <FiUser className="mr-3 text-indigo-600" />,
      action: () => navigate('/student/search-teachers'),
      bg: "bg-gradient-to-r from-indigo-50 to-blue-50 hover:from-indigo-100 hover:to-blue-100"
    },
    {
      title: "My Appointments",
      icon: <FiCalendar className="mr-3 text-purple-600" />,
      action: () => navigate('/student/my-appointments'),
      bg: "bg-gradient-to-r from-purple-50 to-fuchsia-50 hover:from-purple-100 hover:to-fuchsia-100"
    },
    {
      title: "Book Appointment",
      icon: <FiCalendar className="mr-3 text-blue-500" />,
      action: () => navigate('/student/book-appointment'),
      bg: "bg-gradient-to-r from-blue-50 to-cyan-50 hover:from-blue-100 hover:to-cyan-100"
    },
    {
      title: "Messages",
      icon: <FiMessageSquare className="mr-3 text-green-600" />,
      action: () => navigate('/student/message-system'),
      bg: "bg-gradient-to-r from-green-50 to-emerald-50 hover:from-green-100 hover:to-emerald-100"
    }
  ];

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric' 
      });
    } catch {
      return dateString; // Return raw string if parsing fails
    }
  };

  const formatTime = (timeSlot) => {
    return timeSlot.split('-').join(' to ');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center">
              <FiHome className="mr-3 text-indigo-600" />
              Student Dashboard
            </h1>
            <p className="text-gray-600">Welcome back, {currentUser?.firstName || currentUser?.email}</p>
          </div>
          <div className="bg-gradient-to-r from-indigo-100 to-purple-100 p-2 rounded-full">
            <div className="bg-white rounded-full w-10 h-10 flex items-center justify-center text-indigo-600 font-bold">
              {currentUser?.firstName?.charAt(0) || currentUser?.email?.charAt(0)}
            </div>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6">
          {dashboardCards.map((card, index) => (
            <div 
              key={index} 
              onClick={card.action}
              className={`${card.bg} rounded-xl shadow-lg p-4 md:p-6 flex items-center cursor-pointer hover:shadow-xl transition-all transform hover:-translate-y-1`}
            >
              <div className="p-3 rounded-full bg-white/20 backdrop-blur-sm shadow-sm mr-4">
                {card.icon}
              </div>
              <div>
                <p className={`text-sm md:text-base font-medium ${card.textColor}`}>{card.title}</p>
                <p className={`text-xl md:text-2xl font-bold ${card.textColor}`}>{card.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-white/20 backdrop-blur-sm lg:col-span-1">
            <h2 className="text-lg md:text-xl font-semibold mb-4 text-gray-800 flex items-center">
              <FiClock className="mr-2 text-indigo-600" />
              Quick Actions
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-3">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={action.action}
                  className={`${action.bg} text-gray-800 py-3 px-4 rounded-lg transition-all flex items-center text-sm md:text-base font-medium shadow-sm hover:shadow-md`}
                >
                  {action.icon}
                  {action.title}
                </button>
              ))}
            </div>
          </div>

          {/* Upcoming Appointments */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-white/20 backdrop-blur-sm lg:col-span-2">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg md:text-xl font-semibold text-gray-800 flex items-center">
                <FiCalendar className="mr-2 text-indigo-600" />
                Upcoming Appointments
              </h2>
              <button 
                onClick={() => navigate('/student/my-appointments')}
                className="text-indigo-600 hover:text-indigo-800 text-sm flex items-center"
              >
                View All <FiChevronRight className="ml-1" />
              </button>
            </div>
            
            {upcomingAppointments.length === 0 ? (
              <div className="text-center py-8">
                <div className="bg-gradient-to-r from-indigo-50 to-purple-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FiCalendar className="text-indigo-600 text-2xl" />
                </div>
                <p className="text-gray-500">You have no upcoming appointments</p>
                <button
                  onClick={() => navigate('/student/search-teachers')}
                  className="mt-4 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all"
                >
                  Book Appointment
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {upcomingAppointments.map(appointment => (
                  <div 
                    key={appointment.id} 
                    className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/student/my-appointments#appt-${appointment.id}`)}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-gray-800">{appointment.teacherName}</h3>
                        <p className="text-gray-600 text-sm">{appointment.teacherDepartment}</p>
                      </div>
                      <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                        Approved
                      </span>
                    </div>
                    
                    <div className="mt-3 flex items-center">
                      <div className="flex items-center mr-4">
                        <FiCalendar className="text-indigo-500 mr-2" />
                        <span className="text-sm">{formatDate(appointment.date)}</span>
                      </div>
                      <div className="flex items-center">
                        <FiClock className="text-indigo-500 mr-2" />
                        <span className="text-sm">{formatTime(appointment.timeSlot)}</span>
                      </div>
                    </div>
                    
                    <div className="mt-3 flex items-center text-sm">
                      <FiMessageSquare className="text-indigo-500 mr-2" />
                      <p className="text-gray-600 truncate">{appointment.purpose}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Getting Started */}
        <div className="bg-white rounded-xl shadow-lg p-6 border border-white/20 backdrop-blur-sm">
          <h2 className="text-lg md:text-xl font-semibold mb-4 text-gray-800 flex items-center">
            <FiBook className="mr-2 text-indigo-600" />
            Getting Started
          </h2>
          <div className="space-y-4">
            <div className="border-b border-gray-100 pb-4">
              <div className="flex items-start">
                <div className="bg-gradient-to-r from-indigo-100 to-purple-100 p-2 rounded-full mr-3 shadow-sm">
                  <FiUser className="text-indigo-600 text-sm" />
                </div>
                <div>
                  <p className="text-gray-800 font-medium">Find and book appointments with your teachers</p>
                  <button
                    onClick={() => navigate('/student/search-teachers')}
                    className="mt-2 text-sm text-indigo-600 hover:text-indigo-800 flex items-center"
                  >
                    Browse Teachers <FiChevronRight className="ml-1" />
                  </button>
                </div>
              </div>
            </div>
            <div className="border-b border-gray-100 pb-4">
              <div className="flex items-start">
                <div className="bg-gradient-to-r from-blue-100 to-cyan-100 p-2 rounded-full mr-3 shadow-sm">
                  <FiMessageSquare className="text-blue-600 text-sm" />
                </div>
                <div>
                  <p className="text-gray-800 font-medium">Communicate with your teachers via messages</p>
                  <button
                    onClick={() => navigate('/student/message-system')}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    View Messages <FiChevronRight className="ml-1" />
                  </button>
                </div>
              </div>
            </div>
            <div>
              <div className="flex items-start">
                <div className="bg-gradient-to-r from-green-100 to-emerald-100 p-2 rounded-full mr-3 shadow-sm">
                  <FiCalendar className="text-green-600 text-sm" />
                </div>
                <div>
                  <p className="text-gray-800 font-medium">Manage your upcoming appointments</p>
                  <button
                    onClick={() => navigate('/student/my-appointments')}
                    className="mt-2 text-sm text-green-600 hover:text-green-800 flex items-center"
                  >
                    View Appointments <FiChevronRight className="ml-1" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}